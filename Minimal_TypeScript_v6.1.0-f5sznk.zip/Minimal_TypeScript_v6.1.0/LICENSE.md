# License

You can find more details about the license at:

- https://docs.minimals.cc/package
- https://mui.com/store/license/
